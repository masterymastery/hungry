var config = {
    database: 'c_mysql', // 使用哪个数据库
    username: 'root', // 用户名
    password: '123456', // 口令
    host: '62.234.107.218', // 主机名
    port: 3307 // 端口号，MySQL默认3306
};

module.exports = config;