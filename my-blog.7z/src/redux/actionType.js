export const ADDNAME = 'ADDNAME'
export const ADDAGE = 'ADDAGE'

export const GETBOLGLIST = 'GETBOLGLIST'